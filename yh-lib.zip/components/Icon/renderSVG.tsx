function renderSVG(): void {
  const script = document.createElement("script");
  script.src = "//at.alicdn.com/t/font_2014033_h8e487i7165.js";
  document.body.appendChild(script);
}

export default renderSVG;
