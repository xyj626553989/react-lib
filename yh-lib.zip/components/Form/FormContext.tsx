import { createContext } from "react";

const formContext = createContext(null);

export default formContext;
